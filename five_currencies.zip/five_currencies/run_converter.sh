#!/bin/bash
source env/bin/activate
python currency_converter.py
