import requests

# Function to get exchange rates
def get_exchange_rates():
    api_url = 'https://api.exchangerate-api.com/v4/latest/NGN'
    response = requests.get(api_url)
    data = response.json()
    return data['rates']['USD'], data['rates']['GBP']

# Function to convert Naira to Dollar and Pounds
def convert_currency(amount, usd_rate, gbp_rate):
    dollars = amount * usd_rate
    pounds = amount * gbp_rate
    return dollars, pounds

def main():
    try:
        print("Currency converter script is running")
        amount_naira = float(input("Enter amount in Naira: "))
        usd_rate, gbp_rate = get_exchange_rates()
        dollars, pounds = convert_currency(amount_naira, usd_rate, gbp_rate)
        
        print(f"{amount_naira} Naira is equivalent to {dollars:.2f} Dollars.")
        print(f"{amount_naira} Naira is equivalent to {pounds:.2f} Pounds.")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()
